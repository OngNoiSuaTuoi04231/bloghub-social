import React, { useEffect, useState } from "react";
import axios from "axios";

function Admin() {
  const [stats, setStats] = useState({});
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const statsRes = await axios.get(
      "http://localhost:5000/api/admin/stats"
    );

    const usersRes = await axios.get(
      "http://localhost:5000/api/admin/users"
    );

    setStats(statsRes.data);
    setUsers(usersRes.data);
  };

  const banUser = async (id) => {
    await axios.put(
      `http://localhost:5000/api/admin/ban/${id}`
    );

    fetchData();
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1>ADMIN DASHBOARD</h1>

      <h3>Total Users: {stats.totalUsers}</h3>
      <h3>Total Posts: {stats.totalPosts}</h3>
      <h3>Total Reports: {stats.totalReports}</h3>
      <h3>Status: {stats.systemStatus}</h3>

      <hr />

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>User</th>
            <th>Email</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.username}</td>
              <td>{user.email}</td>
              <td>{user.status}</td>
              <td>
                <button
                  onClick={() => banUser(user.id)}
                >
                  Ban
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Admin;