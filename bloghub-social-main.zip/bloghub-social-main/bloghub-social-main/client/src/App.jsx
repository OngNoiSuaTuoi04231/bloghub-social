import Login from "./pages/Login";
import Admin from "./pages/Admin";

function App() {
  return <Login />;
}

export default App;