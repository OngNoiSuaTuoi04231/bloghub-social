const express = require("express");
const router = express.Router();

const users = [
  {
    id: 1,
    username: "admin",
    email: "admin@gmail.com",
    status: "active"
  },
  {
    id: 2,
    username: "nguyenvanA",
    email: "user@gmail.com",
    status: "reported"
  }
];

// Dashboard stats
router.get("/stats", (req, res) => {
  res.json({
    totalUsers: users.length,
    totalPosts: 12,
    totalReports: 2,
    systemStatus: "Online"
  });
});

// Danh sách users
router.get("/users", (req, res) => {
  res.json(users);
});

// Khóa user
router.put("/ban/:id", (req, res) => {
  const user = users.find(
    (u) => u.id == req.params.id
  );

  if (!user) {
    return res.status(404).json({
      message: "User không tồn tại"
    });
  }

  user.status = "banned";

  res.json({
    message: "Khóa tài khoản thành công"
  });
});

module.exports = router;